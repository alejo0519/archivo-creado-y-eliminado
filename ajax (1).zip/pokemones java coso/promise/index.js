const axios=require('axios')
const pokemonName='pikachu'
const ApiUrl=`https://pokeapi.co/api/v2/pokemon/${pokemonName}`

axios(`${ApiUrl}`)
.then(response=>{
        return response.data
    })

.then(response=>{
    console.log(`Nombre: ${response.name}`)
    console.log(`Peso: ${response.weight}`)
    console.log(`Habilidad: ${response.abilities.map((tralalerotralala)=>tralalerotralala.ability.name)}`)
    const speciesUrl=`https://pokeapi.co/api/v2/evolution-chain/${pokemonNumber}/`
})

.catch(err=>{
    console.error(err)
})