const XMLHttpRequest=require('xmlhttprequest').XMLHttpRequest
//Función para la solicitud de la PokeApi mediante un callback
function getPokemon(pokemonName,callback){
//Url de PokeApi
const apiUrl=`https://pokeapi.co/api/v2/pokemon/${pokemonName}`
//Crear instancia 
const xhr=new XMLHttpRequest()
//Configurar solicitud
xhr.open("GET",apiUrl,true)
//Carga exitosa
xhr.onload=function(){
    if(xhr.status===200){
        //Pasear JSON
        const data=JSON.parse(xhr.responseText)
        const name=data.name
        callback(null,name)
    }
    else{
        //Error
        const error=new Error(`Error: ${xhr.status}`)
        callback(error,null)
    }
}
//Manejo de errores de red
xhr.oneerror=function(){
    const error=new Error(`Error: ${xhr.status}`)
    callback(error,null)
}
//Enviar la solicitud
xhr.send()
}
function getPokemonWeight(pokemonName,callback){
    const apiUrl=`https://pokeapi.co/api/v2/pokemon/${pokemonName}`
//Crear instancia 
const xhr=new XMLHttpRequest()
//Configurar solicitud
xhr.open("GET",apiUrl,true)
//Carga exitosa
xhr.onload=function(){
    if(xhr.status===200){
        //Pasear JSON
        const data=JSON.parse(xhr.responseText)
        const weight=data.weight
        callback(null,weight)
    }
    else{
        //Error
        const error=new Error(`Error: ${xhr.status}`)
        callback(error,null)
    }
}
//Manejo de errores de red
xhr.oneerror=function(){
    const error=new Error(`Error: ${xhr.status}`)
    callback(error,null)
}
//Enviar la solicitud
xhr.send()
}

function getPokemonAbilities(pokemonName,callback){
    const apiUrl=`https://pokeapi.co/api/v2/pokemon/${pokemonName}`
    //Crear instancia 
    const xhr=new XMLHttpRequest()
    //Configurar solicitud
    xhr.open("GET",apiUrl,true)
    //Carga exitosa
    xhr.onload=function(){
        if(xhr.status===200){
            //Pasear JSON
            const data=JSON.parse(xhr.responseText)
            const abilities=data.abilities.map((cosa)=>cosa.ability.name)
            callback(null,abilities)
        }
        else{
            //Error
            const error=new Error(`Error: ${xhr.status}`)
            callback(error,null)
        }
    }
    //Manejo de errores de red
    xhr.oneerror=function(){
        const error=new Error(`Error: ${xhr.status}`)
        callback(error,null)
    }
    //Enviar la solicitud
    xhr.send()
    }

getPokemon("pikachu",(error,name)=>{
    if(error){
        console.error(`Error: ${error.message}`)
    }
    else{
        console.log("Nombre",name)
        getPokemonWeight("pikachu",(error,weight)=>{
            if(error){
                console.error(`Error: ${error.message}`)
            }
            else{
                console.log("Peso",weight)
                getPokemonAbilities("pikachu",(error,ability)=>{
                    if(error){
                        console.error(`Error: ${error.message}`)
                    }
                    else{
                        console.log("Habilidad",ability)
                    }
                })
            }
        })
    }
})