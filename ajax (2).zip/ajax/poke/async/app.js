const axios=require('axios')
const pokeName='charmander'
const ApiUrl=`https://pokeapi.co/api/v2/pokemon/${pokeName}`

const pokeData = async () => {
    try{
        const response = await axios.get(`${ApiUrl}`)
        console.log(response.data.name)
        console.log(response.data.weight)
        console.log(response.data.abilities.map((pipis)=>pipis.ability.name))
        const ApiUrl2=response.data.species.url 
        const response2 = await axios.get(`${ApiUrl2}`)
        const ApiUrl3=response2.data.evolution_chain.url
        const response3=await axios.get(`${ApiUrl3}`)
        console.log(response3.data.chain.evolves_to[0].species.name)
    }
    catch(error){
        console.error(error)
    }
}
pokeData()
