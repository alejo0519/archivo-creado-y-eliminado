const XMLHttpRequest=require('xmlhttprequest').XMLHttpRequest

function getPokemon(pokemonName,callback){

const apiUrl=`https://pokeapi.co/api/v2/pokemon/${pokemonName}`

const xhr=new XMLHttpRequest()

xhr.open("GET",apiUrl,true)

xhr.onload=function(){
    if(xhr.status===200){
       
        const data=JSON.parse(xhr.responseText)
        const name=data.name
        callback(null,name)
    }
    else{
     
        const error=new Error(`Error: ${xhr.status}`)
        callback(error,null)
    }
}

xhr.oneerror=function(){
    const error=new Error(`Error: ${xhr.status}`)
    callback(error,null)
}

xhr.send()
}
function getPokemonWeight(pokemonName,callback){
    const apiUrl=`https://pokeapi.co/api/v2/pokemon/${pokemonName}`

const xhr=new XMLHttpRequest()

xhr.open("GET",apiUrl,true)

xhr.onload=function(){
    if(xhr.status===200){
     
        const data=JSON.parse(xhr.responseText)
        const weight=data.weight
        callback(null,weight)
    }
    else{
   
        const error=new Error(`Error: ${xhr.status}`)
        callback(error,null)
    }
}

xhr.oneerror=function(){
    const error=new Error(`Error: ${xhr.status}`)
    callback(error,null)
}

xhr.send()
}

function getPokemonAbilities(pokemonName,callback){
    const apiUrl=`https://pokeapi.co/api/v2/pokemon/${pokemonName}`
    
    const xhr=new XMLHttpRequest()
   
    xhr.open("GET",apiUrl,true)
    
    xhr.onload=function(){
        if(xhr.status===200){
       
            const data=JSON.parse(xhr.responseText)
            const abilities=data.abilities.map((cosa)=>cosa.ability.name)
            callback(null,abilities)
        }
        else{
           
            const error=new Error(`Error: ${xhr.status}`)
            callback(error,null)
        }
    }
    xhr.oneerror=function(){
        const error=new Error(`Error: ${xhr.status}`)
        callback(error,null)
    }
    xhr.send()
    }

getPokemon("pikachu",(error,name)=>{
    if(error){
        console.error(`Error: ${error.message}`)
    }
    else{
        console.log("Nombre",name)
        getPokemonWeight("pikachu",(error,weight)=>{
            if(error){
                console.error(`Error: ${error.message}`)
            }
            else{
                console.log("Peso",weight)
                getPokemonAbilities("pikachu",(error,ability)=>{
                    if(error){
                        console.error(`Error: ${error.message}`)
                    }
                    else{
                        console.log("Habilidad",ability)
                    }
                })
            }
        })
    }
})